/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prueba;

import java.util.Scanner;

/**
 *
 * @author david
 */
public class prueba {
    
     public void ingresarValor() { 
       Scanner teclado=new Scanner(System.in); 
       int valor; 
        do { 
            System.out.print("Ingrese valor:"); 
            valor=teclado.nextInt(); 
            if (valor!=-1) { 
            calcular(valor); 
            } 
        } while (valor!=-1); 
        }//fin metodo ingresarValor() 
     
      public void calcular(int v) { 
       System.out.println("El cuadrado de: "+v +" es: " +(v*v)); 
        }//fin metodo calcular() 
      
      
      public static void main(String[] ar) { 
           prueba invocar; 
           
           invocar=new prueba(); 
           
           invocar.ingresarValor(); 
           
               }//fin metodo main() 
      
           }//fin metodo clase cuadrado 

